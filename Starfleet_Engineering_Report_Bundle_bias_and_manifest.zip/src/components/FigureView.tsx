import React, { useMemo } from "react";
import { Line, Bar, Scatter, Doughnut } from "react-chartjs-2";
import { CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, Filler, ArcElement, Chart as ChartJS } from "chart.js";
import { Figure } from "../types";
import { LCARS } from "../utils/lcars";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, Filler, ArcElement);

export default function FigureView({ fig }: { fig: Figure }){
  const accent = LCARS.accents[(fig.index ?? 0) % LCARS.accents.length];
  const options = useMemo(()=> ({
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { labels: { color: LCARS.fg } }, title: { display: false } },
    scales: { x: { grid: { color: LCARS.grid }, ticks: { color: LCARS.fg } }, y: { grid: { color: LCARS.grid }, ticks: { color: LCARS.fg } } }
  }), []);

  return (
    <div className="rounded-2xl p-4 border border-slate-700 bg-[#101425]">
      <div className="text-sm text-slate-300 mb-2 font-semibold">{fig.id}. {fig.title}</div>
      <div className="h-48">
        {fig.type==="line" && <Line options={options as any} data={{ labels: fig.data.map((_:any,i:number)=>i+1), datasets:[{ label:"Variance", data:fig.data, borderColor:accent, backgroundColor:`${accent}33`, fill:true }] }} />}
        {fig.type==="bar"  && <Bar  options={options as any} data={{ labels: fig.data.map((_:any,i:number)=>`R${i+1}`), datasets:[{ label:"EPS Load", data:fig.data, backgroundColor:accent }] }} />}
        {fig.type==="scatter" && <Scatter options={{...(options as any), plugins:{ ...((options as any).plugins||{}), legend:{ display:false } }}} data={{ datasets:[{ label:"Phase Error", data:fig.data, pointBackgroundColor:accent }] }} />}
        {fig.type==="gauge" && <Doughnut options={{ plugins:{ legend:{ display:false } } }} data={{ labels:["Integrity","Remaining"], datasets:[{ data:[fig.data[0], 100-fig.data[0]], backgroundColor:[accent, "#2a2f45"] }] }} />}
      </div>
      <div className="text-xs text-slate-400 mt-2 italic">{fig.caption} {fig.sectionAnchor ? `(Ref: ${fig.sectionAnchor})` : ""}</div>
    </div>
  );
}
