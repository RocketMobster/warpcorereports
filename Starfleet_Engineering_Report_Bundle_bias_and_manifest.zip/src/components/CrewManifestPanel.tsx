import React from "react";
import { CrewMember } from "../types";

export default function CrewManifestPanel({ list }: { list: CrewMember[] }) {
  if (!list || list.length === 0) return null;
  return (
    <div className="rounded-2xl border border-slate-700 bg-[#101425] p-4">
      <h3 className="text-lg font-semibold mb-2">Crew Manifest Preview</h3>
      <ul className="text-sm text-slate-200 space-y-1">
        {list.map((cm, i) => <li key={i}>• {cm.rank} {cm.name}, {cm.role}</li>)}
      </ul>
    </div>
  );
}
