import React, { useState } from "react";
import { GeneratorConfig, Rank } from "../types";
import { pick, hashCode, xorshift32, POOLS } from "../utils/helpers";

const ranks: Rank[] = [
  "Chief Petty Officer","Senior Chief Petty Officer","Master Chief Petty Officer",
  "Ensign","Lieutenant Junior Grade","Lieutenant","Lieutenant Commander","Commander"
];

export default function ReportControls({ onGenerate, onPreviewCrew }: { onGenerate: (cfg: GeneratorConfig) => void, onPreviewCrew: (count:number, seed?:string)=>void }) {
  const [problemsCount, setProblemsCount] = useState<1|2|3|4|5>(3);
  const [graphsEnabled, setGraphsEnabled] = useState(true);
  const [graphsCount, setGraphsCount] = useState(3);
  const [signatoryName, setSignatoryName] = useState("Craig Bickford");
  const [signatoryRank, setSignatoryRank] = useState<Rank>("Lieutenant Commander");
  const [seed, setSeed] = useState<string>("");
  const [seedLocked, setSeedLocked] = useState<boolean>(false);
  const [lastRandomSeed, setLastRandomSeed] = useState<string>("");
  const [humor, setHumor] = useState<number>(5);

  const handleRandomName = () => {
    const rnd = xorshift32(Math.floor(Math.random() * 1e9));
    setSignatoryName(`${pick(POOLS.crewFirst, rnd)} ${pick(POOLS.crewLast, rnd)}`);
  };

  const handleRandomSeed = () => {
    const s = Math.floor(Math.random() * 1e9).toString(36);
    setLastRandomSeed(s);
    if (!seedLocked) setSeed(s);
  };

  const toggleSeedLock = () => {
    // Quick toggle between last random seed and a fixed one
    if (!seedLocked) {
      // Lock current seed (use lastRandomSeed if present)
      setSeed(prev => prev || lastRandomSeed || Math.floor(Math.random()*1e9).toString(36));
      setSeedLocked(true);
    } else {
      // Unlock and restore lastRandomSeed into the field for convenience
      setSeed(lastRandomSeed);
      setSeedLocked(false);
    }
  };

  const generate = () => {
    const cfg: GeneratorConfig = {
      problemsCount,
      graphsEnabled,
      graphsCount: graphsEnabled ? graphsCount : undefined,
      signatoryName,
      signatoryRank,
      vessel: pick(POOLS.vessels, xorshift32(hashCode(seed || signatoryName))),
      stardate: (50000 + Math.random()*9999).toFixed(1),
      seed: seed || undefined,
      humorLevel: humor
    };
    onGenerate(cfg);
  };

  return (
    <div className="grid md:grid-cols-3 gap-4 mb-6">
      <div className="lcars-card">
        <div className="lcars-rail"></div>
        <div className="lcars-body">
          <label className="lcars-label">Problems</label>
          <input type="range" min={1} max={5} value={problemsCount} onChange={(e)=>setProblemsCount(parseInt(e.target.value) as any)} />
          <div className="lcars-small">{problemsCount}</div>
        </div>
      </div>

      <div className="lcars-card">
        <div className="lcars-rail lcars-rail-alt"></div>
        <div className="lcars-body">
          <label className="lcars-label">Graphs</label>
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={graphsEnabled} onChange={e=>setGraphsEnabled(e.target.checked)} />
            <span className="lcars-small">Enable</span>
          </div>
          {graphsEnabled && <>
            <label className="lcars-label mt-2">How many (1–10)</label>
            <input type="range" min={1} max={10} value={graphsCount} onChange={(e)=>setGraphsCount(parseInt(e.target.value))} />
            <div className="lcars-small">{graphsCount}</div>
          </>}
        </div>
      </div>

      <div className="lcars-card">
        <div className="lcars-rail lcars-rail-accent"></div>
        <div className="lcars-body space-y-2">
          <label className="lcars-label">Signing Engineer</label>
          <div className="flex gap-2">
            <input type="text" value={signatoryName} onChange={e=>setSignatoryName(e.target.value)} className="lcars-input flex-1" />
            <button onClick={handleRandomName} className="lcars-btn">🎲</button>
          </div>
          <label className="lcars-label">Rank</label>
          <select value={signatoryRank} onChange={e=>setSignatoryRank(e.target.value as Rank)} className="lcars-input">
            {ranks.map(r=><option key={r}>{r}</option>)}
          </select>

          <label className="lcars-label">Seed</label>
          <div className="flex gap-2">
            <input type="text" value={seed} onChange={e=>setSeed(e.target.value)} className="lcars-input flex-1" placeholder="optional" />
            <button onClick={handleRandomSeed} className="lcars-btn" title="Random seed">🎲</button>
            <button onClick={toggleSeedLock} className={"lcars-btn " + (seedLocked ? "lcars-btn-locked" : "")} title="Lock/Unlock seed">{seedLocked ? "🔒" : "🔓"}</button>
          </div>

          <label className="lcars-label">Figure Bias</label>
            <select onChange={e=>onGenerate({
              problemsCount, graphsEnabled, graphsCount: graphsEnabled ? graphsCount : undefined, signatoryName, signatoryRank,
              vessel: pick(POOLS.vessels, xorshift32(hashCode(seed || signatoryName))), stardate: (50000 + Math.random()*9999).toFixed(1), seed: seed || undefined, humorLevel: humor, figureBias: e.target.value as any
            })} className="lcars-input">
              <option value="auto">Auto</option>
              <option value="warp">Warp</option>
              <option value="eps">EPS</option>
              <option value="sif">SIF</option>
              <option value="deflector">Deflector</option>
              <option value="transporter">Transporter</option>
              <option value="inertial">Inertial</option>
            </select>
            <label className="lcars-label">Humor Level</label>
          <input type="range" min={0} max={10} value={humor} onChange={e=>setHumor(parseInt(e.target.value))} />
        </div>
      </div>

      <div className="col-span-3 flex gap-2">
        <button onClick={()=>onPreviewCrew(Math.max(3, problemsCount), seed)} className="lcars-btn">Preview Crew Manifest</button>
        <button onClick={generate} className="lcars-cta flex-1">Produce Report</button>
      </div>
    </div>
  );
}
