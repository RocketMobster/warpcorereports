import { GeneratorConfig, Report, Figure, CrewMember, FigureBias } from "../types";
import { pick, randint, POOLS, humorousAside, xorshift32, seedFromConfig } from "./helpers";

type FigType = "line" | "bar" | "scatter" | "gauge";

function preferredTypesFor(system: string, bias: FigureBias): FigType[] {
  if (bias && bias !== "auto") {
    if (bias === "warp") return ["line","scatter"];
    if (bias === "eps") return ["bar","line"];
    if (bias === "sif") return ["gauge","bar"];
    if (bias === "deflector") return ["scatter","line"];
    if (bias === "transporter") return ["scatter","line"];
    if (bias === "inertial") return ["gauge","line"];
  }
  const key = system.toLowerCase();
  if (key.includes("warp")) return ["line","scatter"];
  if (key.includes("eps")) return ["bar","line"];
  if (key.includes("integrity") || key.includes("sif")) return ["gauge","bar"];
  if (key.includes("deflector")) return ["scatter","line"];
  if (key.includes("transporter")) return ["scatter","line"];
  if (key.includes("inertial")) return ["gauge","line"];
  return ["line","bar","scatter","gauge"];
}

function makeFigure(i:number, anchorId:string, sys:string, bias:FigureBias, rnd:()=>number): Figure {
  const prefs = preferredTypesFor(sys, bias);
  const type = prefs[Math.floor(rnd()*prefs.length)];
  const id = `Fig-${i+1}`;
  const title = type==="line" ? "Injector Harmonic Variance (Pre/Post)"
              : type==="bar" ? "EPS Load by Relay"
              : type==="scatter" ? "Phase Error vs. Temperature"
              : "SIF Integrity Gauge";

  const len = 18 + Math.floor(rnd()*20);
  const line = Array.from({length:len},(_,t)=>+(0.4+0.6*Math.exp(-t/8)+rnd()*0.08).toFixed(3));
  const bar = Array.from({length:8},()=>Math.round(40+rnd()*60));
  const scatter = Array.from({length:40},()=>({x:+(rnd()*100).toFixed(2), y:+(rnd()*100).toFixed(2)}));
  const gauge = [65 + Math.floor(rnd()*21)];
  const data = type==="line"?line : type==="bar"?bar : type==="scatter"?scatter : gauge;

  return { id, index:i, title, type, data, caption: "LCARS diagnostic output; post-corrective stability observed.", sectionAnchor: anchorId };
}

function makeCrew(rnd:()=>number): CrewMember {
  const name = `${pick(POOLS.crewFirst, rnd)} ${pick(POOLS.crewLast, rnd)}`;
  const rank = pick(POOLS.crewRanks, rnd);
  const role = pick(POOLS.crewRoles, rnd);
  return { name, rank, role };
}

export function generateCrewManifest(count:number, seed?: string|number, fallbackKey?: string): CrewMember[] {
  const rnd = xorshift32(seedFromConfig(seed, fallbackKey));
  return Array.from({length: count}, () => makeCrew(rnd));
}

export function generateReport(cfg: GeneratorConfig): Report {
  const seedNum = seedFromConfig(cfg.seed, cfg.signatoryName || cfg.stardate);
  const rnd = xorshift32(seedNum);
  const humor = cfg.humorLevel ?? 0;
  const crewManifest: CrewMember[] = [];

  const problems = Array.from({length: cfg.problemsCount}, (_,_i)=>{
    const sys = pick(POOLS.systems, rnd);
    const cm = makeCrew(rnd); crewManifest.push(cm);
    const aside = humorousAside(humor, rnd);
    const base = `Detected anomaly in ${sys}. ${cm.rank} ${cm.name}, ${cm.role}, performed diagnostic baseline and corrective action.`;
    const summary = aside ? `${base} ${aside}` : base;
    return { id:`p${_i+1}`, title:`${sys} Issue`, summary };
  });

  const references = Array.from({length: randint(3,8,rnd)}, (_,i)=>({id:i+1, text:`${i+1}. ${pick(POOLS.crewFirst, rnd)} ${pick(POOLS.crewLast, rnd)} — *${pick(POOLS.systems, rnd)} Diagnostics*, Starfleet Technical Proceedings, 23${randint(50,90,rnd)}.`}));

  const figures: Figure[] = [];
  if (cfg.graphsEnabled) {
    const count = Math.max(1, Math.min(10, cfg.graphsCount ?? 3));
    for (let i=0; i<count; i++) {
      const p = problems[i % problems.length];
      figures.push(makeFigure(i, p.id, p.title, cfg.figureBias ?? "auto", rnd));
    }
  }

  const report: Report = {
    header: { stardate: cfg.stardate, vessel: cfg.vessel, preparedBy:{name:cfg.signatoryName, rank:cfg.signatoryRank, division:"Engineering"}, submittedTo:"Starfleet Corps of Engineers", title:"Starfleet Engineering Report"},
    abstract: "During routine operations, system anomalies were detected and corrected per Starfleet protocols. Post-corrective diagnostics confirm stability within tolerances.",
    problems,
    conclusion: "All systems nominal. Recommend routine monitoring during next three duty cycles.",
    references,
    figures,
    crewManifest,
    humorLevel: humor
  };
  return report;
}

export function reportToTxt(r: Report): string {
  const L: string[] = [];
  L.push(`# ${r.header.title}`);
  L.push(`Stardate: ${r.header.stardate}`);
  L.push(`Vessel: ${r.header.vessel}`);
  L.push(`Prepared By: ${r.header.preparedBy.rank} ${r.header.preparedBy.name}, Engineering`);
  L.push(`Submitted To: ${r.header.submittedTo}`);
  L.push("");
  L.push("Abstract");
  L.push(r.abstract);
  L.push("");

  r.problems.forEach((p,i)=>{
    L.push(`Problem ${i+1}: ${p.title}`);
    L.push(p.summary);
    const figs = (r.figures||[]).filter(f=>f.sectionAnchor===p.id);
    if (figs.length) {
      L.push(`Figures:`);
      figs.forEach(f => L.push(`- ${f.id}: ${f.title} — ${f.caption}`));
    }
    L.push("");
  });

  L.push("Conclusion");
  L.push(r.conclusion);
  L.push("");

  if (r.crewManifest && r.crewManifest.length) {
    L.push("Crew Manifest (Mentioned)");
    r.crewManifest.forEach(cm => L.push(`- ${cm.rank} ${cm.name}, ${cm.role}`));
    L.push("");
  }

  L.push("References");
  (r.references||[]).forEach(ref=>L.push(`[${ref.id}] ${ref.text}`));
  return L.join("\n");
}
