export function pick<T>(arr:T[], rnd:()=>number) { return arr[Math.floor(rnd()*arr.length)] }
export function randint(min:number,max:number,rnd:()=>number) { return Math.floor(rnd()*(max-min+1))+min }
export function hashCode(str:string){ let h=0; for(let i=0;i<str.length;i++){ h=(h<<5)-h+str.charCodeAt(i); h|=0;} return Math.abs(h)}
export function xorshift32(seed:number){ let x=seed||2463534242; return ()=>{ x^=x<<13; x^=x>>>17; x^=x<<5; return (x>>>0)/4294967296; } }

export const POOLS = { crewRanks:["Petty Officer 1st Class","Ensign","Lieutenant Junior Grade","Lieutenant"], crewRoles:["Diagnostic Specialist","Warp Systems Tech","EPS Conduit Tech","Field Modulation Analyst","Engineer"],  vessels:["USS Venture","DS9"], systems:["Warp Core","EPS"], crewFirst:["Marissa","Jonathan"], crewLast:["Noble","Hale"] };

export function humorousAside(level:number, rnd:()=>number): string {
  if (level<=0) return "";
  const chance = Math.min(0.05 + level*0.04, 0.5);
  if (rnd() > chance) return "";
  const bits = [
    "Replicators briefly produced lukewarm stew when 'chocolate sundae' was requested.",
    "A tribble was discovered asleep on the phase discriminator; gently relocated.",
    "Coffee in Engineering reaffirmed as mission-critical resource.",
    "Bussard collectors reported traces of glitter; cause unknown, morale high.",
  ];
  return bits[Math.floor(rnd()*bits.length)];
}

export function seedFromConfig(seed?: string|number, fallbackKey?: string) {
  if (typeof seed === "number") return Math.abs(seed|0) || 2463534242;
  if (typeof seed === "string" && seed.trim().length>0) return hashCode(seed.trim());
  if (fallbackKey && fallbackKey.trim().length>0) return hashCode(fallbackKey.trim());
  return 2463534242;
}
