import { Report } from "../types";
import { Document, Packer, Paragraph, HeadingLevel } from "docx";

export async function buildDocx(report: Report) {
  const parts: Paragraph[] = [] as any;

  parts.push(new Paragraph({ text: report.header.title, heading: HeadingLevel.HEADING_1 }));
  parts.push(new Paragraph(`Stardate: ${report.header.stardate}`));
  parts.push(new Paragraph(`Vessel: ${report.header.vessel}`));
  parts.push(new Paragraph(`Prepared By: ${report.header.preparedBy.rank} ${report.header.preparedBy.name}, Engineering`));
  parts.push(new Paragraph(`Submitted To: ${report.header.submittedTo}`));

  parts.push(new Paragraph({ text: "Abstract", heading: HeadingLevel.HEADING_2 }));
  parts.push(new Paragraph(report.abstract));

  report.problems.forEach((p, idx) => {
    parts.push(new Paragraph({ text: `Problem ${idx+1}: ${p.title}`, heading: HeadingLevel.HEADING_2 }));
    parts.push(new Paragraph(p.summary));
    (report.figures||[]).filter(f=>f.sectionAnchor===p.id).forEach(f=>{
      parts.push(new Paragraph(`Figure ${f.id}: ${f.title} — ${f.caption}`));
    });
  });

  parts.push(new Paragraph({ text: "Conclusion", heading: HeadingLevel.HEADING_2 }));
  parts.push(new Paragraph(report.conclusion));

  if (report.crewManifest && report.crewManifest.length) {
    parts.push(new Paragraph({ text: "Crew Manifest (Mentioned)", heading: HeadingLevel.HEADING_2 }));
    report.crewManifest.forEach(cm => parts.push(new Paragraph(`• ${cm.rank} ${cm.name}, ${cm.role}`)));
  }

  parts.push(new Paragraph({ text: "References", heading: HeadingLevel.HEADING_2 }));
  report.references.forEach(r => parts.push(new Paragraph(`[${r.id}] ${r.text}`)));

  const doc = new Document({ sections: [{ properties: {}, children: parts as any }] });
  return Packer.toBlob(doc);
}
