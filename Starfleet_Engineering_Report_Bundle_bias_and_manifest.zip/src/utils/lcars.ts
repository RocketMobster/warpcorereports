export const LCARS = {
  bg: "#0b0d16",
  fg: "#e8e6e3",
  grid: "#2a2f45",
  accents: ["#ff9966","#ffcc66","#ff6699","#66ccff","#cc99ff","#66ffcc"]
};
