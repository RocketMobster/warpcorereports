import React, { useState } from "react";
import ReportControls from "./components/ReportControls";
import ReportPreview from "./components/ReportPreview";
import CrewManifestPanel from "./components/CrewManifestPanel";
import { generateReport, reportToTxt, generateCrewManifest } from "./utils/reportGen";
import { jsPDF } from "jspdf";
import { saveAs } from "file-saver";
import { Report, GeneratorConfig } from "./types";
import { buildDocx } from "./utils/docxExport";

export default function App() {
  const [report, setReport] = useState<Report | null>(null);
  const [crewPreview, setCrewPreview] = useState<any[]>([]);
  const [lastCfg, setLastCfg] = useState<any | null>(null);
  const [config, setConfig] = useState<GeneratorConfig | null>(null);

  const handleGenerate = (cfg: GeneratorConfig) => {
    const r = generateReport(cfg);
    setReport(r);
    setConfig(cfg);
    setLastCfg(cfg);
  };

  const exportTxt = () => {
    if (!report) return;
    const txt = reportToTxt(report);
    const blob = new Blob([txt], { type: "text/plain" });
    saveAs(blob, "engineering_report.txt");
  };

  const exportPdf = () => {
    if (!report) return;
    const doc = new jsPDF({ unit: "pt", format: "letter" });
    let text = reportToTxt(report);
    const figs = (report.figures || []);
    if (figs.length) {
      text += "\n\nFigure Table";
      figs.forEach(f => { text += `\n${f.id}: ${f.title} — ${f.caption}`; });
    }
    doc.text(text, 48, 48);
    doc.save("engineering_report.pdf");
  };

  const exportDocx = async () => {
    if (!report) return;
    const doc = buildDocx(report);
    const blob = await doc;
    saveAs(blob, "engineering_report.docx");
  };

  return (
    <div className="min-h-screen bg-[#0b0d16] text-slate-100 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-2xl font-extrabold mb-6">Starfleet Engineering Report Generator</h1>
        <ReportControls onGenerate={handleGenerate} onPreviewCrew={(count, seed)=>setCrewPreview(generateCrewManifest(count, seed, "preview"))} />
        {crewPreview.length>0 && (
          <div className="mb-6"><CrewManifestPanel list={crewPreview} /></div>
        )}
        <div className="flex gap-3 mb-6">
          <button onClick={exportTxt} className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700">Download TXT</button>
          <button onClick={exportPdf} className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700">Download PDF</button>
          <button onClick={exportDocx} className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700">Download DOCX</button>
        </div>
        {report ? <ReportPreview report={report} /> : <div>No report yet.</div>}
      </div>
    </div>
  );
}
