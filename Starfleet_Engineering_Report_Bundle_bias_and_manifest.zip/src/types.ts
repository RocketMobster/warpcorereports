export type Rank = "Chief Petty Officer" | "Senior Chief Petty Officer" | "Master Chief Petty Officer" | "Ensign" | "Lieutenant Junior Grade" | "Lieutenant" | "Lieutenant Commander" | "Commander";

export interface GeneratorConfig {
  problemsCount: 1|2|3|4|5;
  graphsEnabled: boolean;
  graphsCount?: number;
  signatoryName: string;
  signatoryRank: Rank;
  vessel: string;
  stardate: string;
  seed?: string | number;
  humorLevel?: number;
  figureBias?: FigureBias;
}

export interface ProblemSection { id: string; title: string; summary: string; }
export interface Reference { id: number; text: string }

export interface Report {
  header: { stardate: string; vessel: string; preparedBy: { name: string; rank: Rank; division: string }; submittedTo: string; title: string };
  abstract: string;
  problems: ProblemSection[];
  conclusion: string;
  references: Reference[];
  figures?: Figure[];
  crewManifest?: CrewMember[];
  humorLevel?: number;
  figureBias?: FigureBias;
  figures?: Figure[];
}

export type FigureType = "line" | "bar" | "scatter" | "gauge";

export interface Figure {
  id: string;
  index?: number;
  title: string;
  type: FigureType;
  data: any;
  caption: string;
  sectionAnchor?: string;
}

export interface CrewMember { name: string; rank: string; role: string; }

export type FigureBias = "auto" | "warp" | "eps" | "sif" | "deflector" | "transporter" | "inertial";
