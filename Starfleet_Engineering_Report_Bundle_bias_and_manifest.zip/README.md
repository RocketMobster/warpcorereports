# Starfleet Engineering Report Generator

## Quick Start
```bash
npm i
npm run dev
```
Open the URL shown (usually http://localhost:5173).

## Build
```bash
npm run build
npm run preview
```


## Reproducible Output (Seed)
- Use the Seed field to get deterministic reports.
- Same inputs + same seed => same report every time.



## New Controls
- **Figure Bias**: pick Auto, Warp, EPS, SIF, Deflector, Transporter, Inertial to bias chart types.
- **Preview Crew Manifest**: generates the crew list that will be referenced before producing the report.
- **Seed Lock & Randomizer**: lock the seed for deterministic output or roll a new one.
